#' @title firthDat
#'
#' @description a generated data
#'
#' @docType data
#'
#' @usage data(firthDat)
#'
#' @format An object of class \code{"data.frame"}
#'
#' @keywords datasets
#'
#' @examples
#'
#'  data(firthDat)
#'
#'  names(firthDat)
#'
#'
"firthDat"

