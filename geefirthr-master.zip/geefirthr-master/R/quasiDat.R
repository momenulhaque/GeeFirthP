#'
#'
#'  a generated data
#'
#' @docType data
#'
#' @usage data(quasiDat)
#'
#' @format An object of class \code{"data.frame"}
#'
#' @keywords datasets
#'
#' @examples
#'
#'  data(quasiDat)
#'
#'  names(quasiDat)
#'
#'
"quasiDat"
#' [1] "quasiDat"

