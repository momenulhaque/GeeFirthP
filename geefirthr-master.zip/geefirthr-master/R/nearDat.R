#' @title nearDat
#'
#' @description a generated data
#'
#' @docType data
#'
#' @usage data(nearDat)
#'
#' @format An object of class \code{"data.frame"}
#'
#' @keywords datasets
#'
#' @examples
#'
#'  data(nearDat)
#'
#'  names(nearDat)
#'
#'
"nearDat"

